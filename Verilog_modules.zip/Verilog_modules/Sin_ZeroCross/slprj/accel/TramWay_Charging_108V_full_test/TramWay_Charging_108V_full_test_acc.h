#include "__cf_TramWay_Charging_108V_full_test.h"
#ifndef RTW_HEADER_TramWay_Charging_108V_full_test_acc_h_
#define RTW_HEADER_TramWay_Charging_108V_full_test_acc_h_
#include <stddef.h>
#include <float.h>
#include <string.h>
#ifndef TramWay_Charging_108V_full_test_acc_COMMON_INCLUDES_
#define TramWay_Charging_108V_full_test_acc_COMMON_INCLUDES_
#include <stdlib.h>
#define S_FUNCTION_NAME simulink_only_sfcn 
#define S_FUNCTION_LEVEL 2
#define RTW_GENERATED_S_FUNCTION
#include "sl_AsyncioQueue/AsyncioQueueCAPI.h"
#include "simtarget/slSimTgtSigstreamRTW.h"
#include "simtarget/slSimTgtSlioCoreRTW.h"
#include "simtarget/slSimTgtSlioClientsRTW.h"
#include "simtarget/slSimTgtSlioSdiRTW.h"
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "TramWay_Charging_108V_full_test_acc_types.h"
#include "multiword_types.h"
#include "mwmathutil.h"
#include "rtGetInf.h"
#include "rt_defines.h"
#include "rt_nonfinite.h"
typedef struct { real_T B_22_0_0 [ 37 ] ; real_T B_22_1_0 ; real_T B_22_2_0 ;
real_T B_22_3_0 ; real_T B_22_10_0 ; real_T B_22_11_0 ; real_T B_22_15_0 ;
real_T B_22_22_0 ; real_T B_22_23_0 ; real_T B_22_31_0 ; real_T B_22_32_0 ;
real_T B_22_33_0 ; real_T B_22_39_0 ; real_T B_22_49_0 ; real_T B_22_51_0 ;
real_T B_22_52_0 ; real_T B_22_53_0 ; real_T B_22_54_0 ; real_T B_22_55_0 ;
real_T B_22_56_0 ; real_T B_22_57_0 ; real_T B_22_58_0 ; real_T B_22_59_0 ;
real_T B_22_60_0 ; real_T B_22_61_0 ; real_T B_22_62_0 [ 59 ] ; real_T
B_22_62_1 [ 37 ] ; real_T B_22_63_0 ; real_T B_22_64_0 ; real_T B_22_65_0 ;
real_T B_22_67_0 ; real_T B_22_68_0 ; real_T B_22_70_0 ; real_T B_22_71_0 ;
real_T B_22_72_0 ; real_T B_22_74_0 ; real_T B_22_75_0 ; real_T B_22_76_0 ;
real_T B_22_77_0 ; real_T B_22_81_0 ; real_T B_22_84_0 ; real_T B_22_87_0 ;
real_T B_22_89_0 ; real_T B_22_91_0 ; real_T B_22_92_0 ; real_T B_22_95_0 ;
real_T B_22_96_0 ; real_T B_22_98_0 ; real_T B_22_100_0 ; real_T B_22_102_0 ;
real_T B_22_105_0 ; real_T B_22_106_0 ; real_T B_22_107_0 ; real_T B_22_110_0
; real_T B_22_111_0 ; real_T B_22_112_0 ; real_T B_22_113_0 ; real_T
B_22_116_0 ; real_T B_22_117_0 ; real_T B_22_118_0 ; real_T B_22_119_0 ;
real_T B_22_122_0 ; real_T B_22_124_0 ; real_T B_22_129_0 ; real_T B_22_131_0
; real_T B_22_133_0 ; real_T B_22_135_0 ; real_T B_22_137_0 ; real_T
B_22_138_0 ; real_T B_22_141_0 ; real_T B_22_142_0 ; real_T B_22_144_0 ;
real_T B_22_146_0 ; real_T B_22_148_0 ; real_T B_22_149_0 ; real_T B_22_151_0
; real_T B_22_155_0 ; real_T B_22_157_0 ; real_T B_22_159_0 ; real_T
B_22_162_0 ; real_T B_22_163_0 ; real_T B_22_164_0 ; real_T B_22_165_0 ;
real_T B_22_262_0 ; real_T B_22_265_0 ; real_T B_22_268_0 ; real_T B_22_274_0
; real_T B_22_276_0 ; real_T B_22_278_0 ; real_T B_22_280_0 ; real_T
B_22_282_0 ; real_T B_22_286_0 ; real_T B_22_287_0 ; real_T B_22_290_0 ;
real_T B_22_294_0 ; real_T B_22_295_0 ; real_T B_22_296_0 ; real_T B_22_297_0
; real_T B_22_298_0 ; real_T B_22_301_0 ; real_T B_22_326_0 ; real_T
B_22_327_0 ; real_T B_22_328_0 [ 2 ] ; real_T B_22_330_0 ; real_T B_22_332_0
; real_T B_22_336_0 ; real_T B_22_339_0 ; real_T B_22_341_0 ; real_T
B_22_343_0 [ 3 ] ; real_T B_22_344_0 ; real_T B_22_349_0 [ 3 ] ; real_T
B_22_352_0 [ 6 ] ; real_T B_22_354_0 ; real_T B_22_355_0 ; real_T B_22_356_0
[ 6 ] ; real_T B_22_366_0 ; real_T B_22_367_0 ; real_T B_22_368_0 ; real_T
B_22_374_0 ; real_T B_22_375_0 ; real_T B_22_377_0 ; real_T B_22_385_0 ;
real_T B_22_393_0 ; real_T B_22_394_0 ; real_T B_22_395_0 ; real_T B_22_399_0
; real_T B_22_400_0 ; real_T B_22_402_0 ; real_T B_22_406_0 ; real_T
B_22_407_0 ; real_T B_22_410_0 ; real_T B_22_417_0 ; real_T B_22_424_0 ;
real_T B_22_433_0 ; real_T B_22_440_0 ; real_T B_22_457_0 ; real_T B_22_458_0
; real_T B_22_465_0 ; real_T B_22_484_0 [ 2 ] ; real_T B_22_485_0 [ 2 ] ;
real_T B_22_486_0 [ 2 ] ; real_T B_22_487_0 [ 2 ] ; real_T B_22_490_0 ;
real_T B_22_499_0 ; real_T B_22_508_0 ; real_T B_22_517_0 ; real_T B_22_534_0
; real_T B_22_538_0 ; real_T B_22_542_0 ; real_T B_22_554_0 ; real_T
B_22_558_0 ; real_T B_22_562_0 ; real_T B_22_574_0 ; real_T B_22_578_0 ;
real_T B_22_582_0 ; real_T B_22_594_0 ; real_T B_22_598_0 ; real_T B_22_602_0
; real_T B_22_615_0 ; real_T B_22_616_0 ; boolean_T B_22_82_0 ; boolean_T
B_22_85_0 ; boolean_T B_22_99_0 ; boolean_T B_22_103_0 ; boolean_T B_22_108_0
; boolean_T B_22_109_0 ; boolean_T B_22_152_0 ; boolean_T B_22_156_0 ;
boolean_T B_22_158_0 ; boolean_T B_22_160_0 ; boolean_T B_22_279_0 ;
boolean_T B_22_299_0 ; char_T pad_B_22_299_0 [ 4 ] ; }
B_TramWay_Charging_108V_full_test_T ; typedef struct { real_T
Currentfilter_states ; real_T inti_DSTATE ; real_T
DiscreteTimeIntegrator_DSTATE ; real_T StateSpace_DSTATE [ 32 ] ; real_T
UnitDelay2_DSTATE ; real_T Integrator_DSTATE ; real_T UnitDelay15_DSTATE ;
real_T Integrator_DSTATE_c ; real_T UnitDelay1_DSTATE ; real_T
Integrator_DSTATE_a ; real_T UnitDelay11_DSTATE ; real_T UnitDelay14_DSTATE ;
real_T UnitDelay16_DSTATE ; real_T UnitDelay15_DSTATE_l ; real_T Delay_DSTATE
[ 800 ] ; real_T UnitDelay11_DSTATE_h ; real_T UnitDelay14_DSTATE_d ; real_T
UnitDelay15_DSTATE_e ; real_T itinit1_PreviousInput ; real_T
itinit_PreviousInput ; real_T Memory2_PreviousInput ; real_T
Memory_PreviousInput ; real_T Memory_PreviousInput_m ; real_T
Memory2_PreviousInput_h ; real_T Memory_PreviousInput_k ; real_T
Memory1_PreviousInput ; struct { real_T modelTStart ; } TransportDelay2_RWORK
; struct { real_T modelTStart ; } TransportDelay3_RWORK ; struct { real_T
modelTStart ; } TransportDelay2_RWORK_m ; struct { real_T modelTStart ; }
TransportDelay3_RWORK_p ; struct { void * AS ; void * BS ; void * CS ; void *
DS ; void * DX_COL ; void * BD_COL ; void * TMP1 ; void * TMP2 ; void * XTMP
; void * SWITCH_STATUS ; void * SWITCH_STATUS_INIT ; void * SW_CHG ; void *
G_STATE ; void * USWLAST ; void * XKM12 ; void * XKP12 ; void * XLAST ; void
* ULAST ; void * IDX_SW_CHG ; void * Y_SWITCH ; void * SWITCH_TYPES ; void *
IDX_OUT_SW ; void * SWITCH_TOPO_SAVED_IDX ; void * SWITCH_MAP ; }
StateSpace_PWORK ; void * I_BUCK_1_PWORK [ 3 ] ; void * I_U_DC_PWORK [ 2 ] ;
void * I_U_DC1_PWORK [ 3 ] ; void * PID_Current_PWORK [ 3 ] ; struct { void *
TUbufferPtrs [ 2 ] ; } TransportDelay2_PWORK ; struct { void * TUbufferPtrs [
2 ] ; } TransportDelay3_PWORK ; void * Scope9_PWORK [ 3 ] ; struct { void *
TUbufferPtrs [ 2 ] ; } TransportDelay2_PWORK_d ; struct { void * TUbufferPtrs
[ 2 ] ; } TransportDelay3_PWORK_e ; void * PID_Voltage_PWORK [ 7 ] ; void *
PID_Modulation_PWORK [ 3 ] ; void * Invertor_control_PWORK [ 3 ] ; void *
U_Transformer_PWORK [ 3 ] ; struct { void * AQHandles ; void * SlioLTF ; }
HiddenToAsyncQueue_InsertedFor_Switch_at_outport_0_PWORK ; void *
BATTERY_PWORK [ 3 ] ; void * Scope9_PWORK_i [ 3 ] ; void * I_U_LOAD_PWORK [ 2
] ; void * Input_PWORK [ 2 ] ; void * ToWorkspace_PWORK ; void *
ToWorkspace_PWORK_d ; void * ToWorkspace_PWORK_g ; void * ToWorkspace_PWORK_h
; int32_T StoreData_sysIdxToRun ; int32_T StoreData_sysIdxToRun_l ; int32_T
StoreData_sysIdxToRun_m ; int32_T StoreData_sysIdxToRun_n ; int32_T
TmpAtomicSubsysAtSwitch2Inport3_sysIdxToRun ; int32_T
TmpAtomicSubsysAtSwitch2Inport3_sysIdxToRun_c ; int32_T
TmpAtomicSubsysAtSwitch2Inport3_sysIdxToRun_e ; int32_T
TmpAtomicSubsysAtMultiportSwitch1Inport3_sysIdxToRun ; int32_T
TmpAtomicSubsysAtMultiportSwitch1Inport2_sysIdxToRun ; int32_T
TmpAtomicSubsysAtMultiportSwitch1Inport3_sysIdxToRun_o ; int32_T
TmpAtomicSubsysAtMultiportSwitch1Inport4_sysIdxToRun ; int32_T
TmpAtomicSubsysAtMultiportSwitch1Inport5_sysIdxToRun ; int32_T
TmpAtomicSubsysAtSwitch2Inport1_sysIdxToRun ; int32_T
TmpAtomicSubsysAtSwitch1Inport1_sysIdxToRun ; int32_T
TmpAtomicSubsysAtSwitch2Inport1_sysIdxToRun_j ; int32_T
TmpAtomicSubsysAtSwitch2Inport3_sysIdxToRun_a ; int32_T
TmpAtomicSubsysAtSwitch4Inport1_sysIdxToRun ; int32_T
TmpAtomicSubsysAtSwitch4Inport3_sysIdxToRun ; int32_T
TmpAtomicSubsysAtSwitch4Inport1_sysIdxToRun_d ; int32_T
TmpAtomicSubsysAtSwitch5Inport1_sysIdxToRun ; int32_T
TmpAtomicSubsysAtSwitch5Inport3_sysIdxToRun ; int32_T
TmpAtomicSubsysAtSwitch5Inport1_sysIdxToRun_k ; uint32_T CircBufIdx ;
uint32_T m_bpIndex ; int_T StateSpace_IWORK [ 11 ] ; struct { int_T Tail ;
int_T Head ; int_T Last ; int_T CircularBufSize ; int_T MaxNewBufSize ; }
TransportDelay2_IWORK ; struct { int_T Tail ; int_T Head ; int_T Last ; int_T
CircularBufSize ; int_T MaxNewBufSize ; } TransportDelay3_IWORK ; struct {
int_T Tail ; int_T Head ; int_T Last ; int_T CircularBufSize ; int_T
MaxNewBufSize ; } TransportDelay2_IWORK_h ; struct { int_T Tail ; int_T Head
; int_T Last ; int_T CircularBufSize ; int_T MaxNewBufSize ; }
TransportDelay3_IWORK_a ; int8_T inti_PrevResetState ; int8_T
Integrator_PrevResetState ; int8_T Integrator_PrevResetState_k ; int8_T
Integrator_PrevResetState_a ; int8_T StoreData_SubsysRanBC ; int8_T
StoreData_SubsysRanBC_b ; int8_T StoreData_SubsysRanBC_bn ; int8_T
StoreData_SubsysRanBC_k ; uint8_T inti_IC_LOADING ; uint8_T inti_NumInitCond
; uint8_T DiscreteTimeIntegrator_NumInitCond ; char_T
pad_DiscreteTimeIntegrator_NumInitCond [ 1 ] ; }
DW_TramWay_Charging_108V_full_test_T ; typedef struct { real_T
Integrator_CSTATE ; real_T Integrator_CSTATE_k ; real_T Integrator_CSTATE_l ;
} X_TramWay_Charging_108V_full_test_T ; typedef struct { real_T
Integrator_CSTATE ; real_T Integrator_CSTATE_k ; real_T Integrator_CSTATE_l ;
} XDot_TramWay_Charging_108V_full_test_T ; typedef struct { boolean_T
Integrator_CSTATE ; boolean_T Integrator_CSTATE_k ; boolean_T
Integrator_CSTATE_l ; } XDis_TramWay_Charging_108V_full_test_T ; typedef
struct { ZCSigState Integrator_Reset_ZCE ; ZCSigState Delay_Reset_ZCE ;
ZCSigState Integrator_Reset_ZCE_h ; }
PrevZCX_TramWay_Charging_108V_full_test_T ; typedef const struct
tag_ConstB_TramWay_Charging_108V_full_test_T { real_T B_22_8_0 ; real_T
B_22_28_0 ; real_T B_22_387_0 ; } ConstB_TramWay_Charging_108V_full_test_T ;
#define TramWay_Charging_108V_full_test_rtC(S) ((ConstB_TramWay_Charging_108V_full_test_T *) _ssGetConstBlockIO(S))
struct P_TramWay_Charging_108V_full_test_T_ { real_T P_0 ; real_T P_1 ;
real_T P_2 ; real_T P_3 [ 37 ] ; real_T P_4 ; real_T P_5 ; real_T P_6 ;
real_T P_7 ; real_T P_8 ; real_T P_9 ; real_T P_10 [ 2 ] ; real_T P_11 ;
real_T P_12 ; real_T P_13 ; real_T P_14 ; real_T P_15 ; real_T P_16 ; real_T
P_17 ; real_T P_18 ; real_T P_19 ; real_T P_20 ; real_T P_21 ; real_T P_22 ;
real_T P_23 ; real_T P_24 ; real_T P_25 ; real_T P_26 ; real_T P_27 ; real_T
P_28 ; real_T P_29 ; real_T P_30 ; real_T P_31 [ 9 ] ; real_T P_32 [ 9 ] ;
real_T P_33 ; real_T P_34 ; real_T P_35 ; real_T P_36 ; real_T P_37 ; real_T
P_38 ; real_T P_39 ; real_T P_40 ; real_T P_41 ; real_T P_42 ; real_T P_43 [
2 ] ; real_T P_44 [ 1024 ] ; real_T P_45 [ 2 ] ; real_T P_46 [ 1600 ] ;
real_T P_47 [ 2 ] ; real_T P_48 [ 1888 ] ; real_T P_49 [ 2 ] ; real_T P_50 [
2950 ] ; real_T P_51 [ 2 ] ; real_T P_52 [ 32 ] ; real_T P_53 ; real_T P_54 ;
real_T P_55 ; real_T P_56 ; real_T P_57 ; real_T P_58 ; real_T P_59 ; real_T
P_60 ; real_T P_61 ; real_T P_62 ; real_T P_63 ; real_T P_64 ; real_T P_65 ;
real_T P_66 ; real_T P_67 ; real_T P_68 [ 2 ] ; real_T P_69 [ 2 ] ; real_T
P_70 ; real_T P_71 ; real_T P_72 ; real_T P_73 ; real_T P_74 ; real_T P_75 ;
real_T P_76 ; real_T P_77 ; real_T P_78 ; real_T P_79 ; real_T P_80 ; real_T
P_81 ; real_T P_82 ; real_T P_83 ; real_T P_84 ; real_T P_85 ; real_T P_86 ;
real_T P_87 ; real_T P_88 ; real_T P_89 ; real_T P_90 ; real_T P_91 ; real_T
P_92 ; real_T P_93 ; real_T P_94 ; real_T P_95 ; real_T P_96 ; real_T P_97 ;
real_T P_98 ; real_T P_99 ; real_T P_100 ; real_T P_101 ; real_T P_102 ;
real_T P_103 ; real_T P_104 ; real_T P_105 ; real_T P_106 ; real_T P_107 ;
real_T P_108 ; real_T P_109 ; real_T P_110 ; real_T P_111 ; real_T P_112 ;
real_T P_113 [ 2 ] ; real_T P_114 [ 2 ] ; real_T P_115 ; real_T P_116 ;
real_T P_117 ; real_T P_118 ; real_T P_119 ; real_T P_120 ; real_T P_121 ;
real_T P_122 ; real_T P_123 ; real_T P_124 ; real_T P_125 ; real_T P_126 ;
real_T P_127 ; real_T P_128 ; real_T P_129 ; real_T P_130 ; real_T P_131 ;
real_T P_132 ; real_T P_133 ; real_T P_134 ; real_T P_135 ; real_T P_136 ;
real_T P_137 ; real_T P_138 ; real_T P_139 ; real_T P_140 ; real_T P_141 ;
real_T P_142 ; real_T P_143 ; real_T P_144 ; real_T P_145 ; real_T P_146 ;
real_T P_147 [ 2 ] ; real_T P_148 ; real_T P_149 ; real_T P_150 ; real_T
P_151 [ 3 ] ; real_T P_152 [ 3 ] ; real_T P_153 ; real_T P_154 ; real_T P_155
; real_T P_156 [ 3 ] ; real_T P_157 ; real_T P_158 ; real_T P_159 ; real_T
P_160 ; real_T P_161 ; real_T P_162 ; real_T P_163 ; real_T P_164 ; real_T
P_165 ; real_T P_166 ; real_T P_167 ; real_T P_168 ; real_T P_169 ; real_T
P_170 ; real_T P_171 ; real_T P_172 ; real_T P_173 ; real_T P_174 ; real_T
P_175 ; real_T P_176 ; real_T P_177 ; real_T P_178 ; real_T P_179 ; real_T
P_180 ; real_T P_181 ; real_T P_182 ; real_T P_183 ; real_T P_184 ; real_T
P_185 ; real_T P_186 ; real_T P_187 ; real_T P_188 ; real_T P_189 ; real_T
P_190 ; real_T P_191 ; real_T P_192 ; real_T P_193 ; real_T P_194 ; real_T
P_195 ; real_T P_196 ; real_T P_197 ; real_T P_198 ; real_T P_199 ; real_T
P_200 ; real_T P_201 ; real_T P_202 [ 2 ] ; real_T P_203 [ 2 ] ; real_T P_204
[ 2 ] ; real_T P_205 [ 2 ] ; real_T P_206 ; real_T P_207 ; real_T P_208 ;
real_T P_209 ; real_T P_210 ; real_T P_211 ; real_T P_212 ; real_T P_213 ;
real_T P_214 ; real_T P_215 ; real_T P_216 ; real_T P_217 ; real_T P_218 ;
real_T P_219 ; real_T P_220 ; real_T P_221 ; uint32_T P_222 ; char_T
pad_P_222 [ 4 ] ; } ; extern P_TramWay_Charging_108V_full_test_T
TramWay_Charging_108V_full_test_rtDefaultP ; extern const
ConstB_TramWay_Charging_108V_full_test_T
TramWay_Charging_108V_full_test_rtInvariant ;
#endif
