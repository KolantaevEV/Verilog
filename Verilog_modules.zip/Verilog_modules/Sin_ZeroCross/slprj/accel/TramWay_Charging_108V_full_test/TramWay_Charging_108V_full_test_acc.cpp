#include "__cf_TramWay_Charging_108V_full_test.h"
#include <math.h>
#include "TramWay_Charging_108V_full_test_acc.h"
#include "TramWay_Charging_108V_full_test_acc_private.h"
#include <stdio.h>
#include "slexec_vm_simstruct_bridge.h"
#include "slexec_vm_zc_functions.h"
#include "slexec_vm_lookup_functions.h"
#include "slsv_diagnostic_codegen_c_api.h"
#include "simstruc.h"
#include "fixedpoint.h"
#define CodeFormat S-Function
#define AccDefine1 Accelerator_S-Function
#include "simtarget/slAccSfcnBridge.h"
#ifndef __RTW_UTFREE__  
#ifdef __cplusplus
extern "C" {
#endif
extern void * utMalloc ( size_t ) ; extern void utFree ( void * ) ;
#ifdef __cplusplus
}
#endif
#endif
boolean_T TramWay_Charging_108V_full_test_acc_rt_TDelayUpdateTailOrGrowBuf (
int_T * bufSzPtr , int_T * tailPtr , int_T * headPtr , int_T * lastPtr ,
real_T tMinusDelay , real_T * * tBufPtr , real_T * * uBufPtr , real_T * *
xBufPtr , boolean_T isfixedbuf , boolean_T istransportdelay , int_T *
maxNewBufSzPtr ) { int_T testIdx ; int_T tail = * tailPtr ; int_T bufSz = *
bufSzPtr ; real_T * tBuf = * tBufPtr ; real_T * xBuf = ( NULL ) ; int_T
numBuffer = 2 ; if ( istransportdelay ) { numBuffer = 3 ; xBuf = * xBufPtr ;
} testIdx = ( tail < ( bufSz - 1 ) ) ? ( tail + 1 ) : 0 ; if ( ( tMinusDelay
<= tBuf [ testIdx ] ) && ! isfixedbuf ) { int_T j ; real_T * tempT ; real_T *
tempU ; real_T * tempX = ( NULL ) ; real_T * uBuf = * uBufPtr ; int_T
newBufSz = bufSz + 1024 ; if ( newBufSz > * maxNewBufSzPtr ) { *
maxNewBufSzPtr = newBufSz ; } tempU = ( real_T * ) utMalloc ( numBuffer *
newBufSz * sizeof ( real_T ) ) ; if ( tempU == ( NULL ) ) { return ( false )
; } tempT = tempU + newBufSz ; if ( istransportdelay ) tempX = tempT +
newBufSz ; for ( j = tail ; j < bufSz ; j ++ ) { tempT [ j - tail ] = tBuf [
j ] ; tempU [ j - tail ] = uBuf [ j ] ; if ( istransportdelay ) tempX [ j -
tail ] = xBuf [ j ] ; } for ( j = 0 ; j < tail ; j ++ ) { tempT [ j + bufSz -
tail ] = tBuf [ j ] ; tempU [ j + bufSz - tail ] = uBuf [ j ] ; if (
istransportdelay ) tempX [ j + bufSz - tail ] = xBuf [ j ] ; } if ( * lastPtr
> tail ) { * lastPtr -= tail ; } else { * lastPtr += ( bufSz - tail ) ; } *
tailPtr = 0 ; * headPtr = bufSz ; utFree ( uBuf ) ; * bufSzPtr = newBufSz ; *
tBufPtr = tempT ; * uBufPtr = tempU ; if ( istransportdelay ) * xBufPtr =
tempX ; } else { * tailPtr = testIdx ; } return ( true ) ; } real_T
TramWay_Charging_108V_full_test_acc_rt_TDelayInterpolate ( real_T tMinusDelay
, real_T tStart , real_T * tBuf , real_T * uBuf , int_T bufSz , int_T *
lastIdx , int_T oldestIdx , int_T newIdx , real_T initOutput , boolean_T
discrete , boolean_T minorStepAndTAtLastMajorOutput ) { int_T i ; real_T yout
, t1 , t2 , u1 , u2 ; if ( ( newIdx == 0 ) && ( oldestIdx == 0 ) && (
tMinusDelay > tStart ) ) return initOutput ; if ( tMinusDelay <= tStart )
return initOutput ; if ( ( tMinusDelay <= tBuf [ oldestIdx ] ) ) { if (
discrete ) { return ( uBuf [ oldestIdx ] ) ; } else { int_T tempIdx =
oldestIdx + 1 ; if ( oldestIdx == bufSz - 1 ) tempIdx = 0 ; t1 = tBuf [
oldestIdx ] ; t2 = tBuf [ tempIdx ] ; u1 = uBuf [ oldestIdx ] ; u2 = uBuf [
tempIdx ] ; if ( t2 == t1 ) { if ( tMinusDelay >= t2 ) { yout = u2 ; } else {
yout = u1 ; } } else { real_T f1 = ( t2 - tMinusDelay ) / ( t2 - t1 ) ;
real_T f2 = 1.0 - f1 ; yout = f1 * u1 + f2 * u2 ; } return yout ; } } if (
minorStepAndTAtLastMajorOutput ) { if ( newIdx != 0 ) { if ( * lastIdx ==
newIdx ) { ( * lastIdx ) -- ; } newIdx -- ; } else { if ( * lastIdx == newIdx
) { * lastIdx = bufSz - 1 ; } newIdx = bufSz - 1 ; } } i = * lastIdx ; if (
tBuf [ i ] < tMinusDelay ) { while ( tBuf [ i ] < tMinusDelay ) { if ( i ==
newIdx ) break ; i = ( i < ( bufSz - 1 ) ) ? ( i + 1 ) : 0 ; } } else { while
( tBuf [ i ] >= tMinusDelay ) { i = ( i > 0 ) ? i - 1 : ( bufSz - 1 ) ; } i =
( i < ( bufSz - 1 ) ) ? ( i + 1 ) : 0 ; } * lastIdx = i ; if ( discrete ) {
double tempEps = ( DBL_EPSILON ) * 128.0 ; double localEps = tempEps *
muDoubleScalarAbs ( tBuf [ i ] ) ; if ( tempEps > localEps ) { localEps =
tempEps ; } localEps = localEps / 2.0 ; if ( tMinusDelay >= ( tBuf [ i ] -
localEps ) ) { yout = uBuf [ i ] ; } else { if ( i == 0 ) { yout = uBuf [
bufSz - 1 ] ; } else { yout = uBuf [ i - 1 ] ; } } } else { if ( i == 0 ) {
t1 = tBuf [ bufSz - 1 ] ; u1 = uBuf [ bufSz - 1 ] ; } else { t1 = tBuf [ i -
1 ] ; u1 = uBuf [ i - 1 ] ; } t2 = tBuf [ i ] ; u2 = uBuf [ i ] ; if ( t2 ==
t1 ) { if ( tMinusDelay >= t2 ) { yout = u2 ; } else { yout = u1 ; } } else {
real_T f1 = ( t2 - tMinusDelay ) / ( t2 - t1 ) ; real_T f2 = 1.0 - f1 ; yout
= f1 * u1 + f2 * u2 ; } } return ( yout ) ; } real_T look1_binlxpw ( real_T
u0 , const real_T bp0 [ ] , const real_T table [ ] , uint32_T maxIndex ) {
real_T frac ; uint32_T iRght ; uint32_T iLeft ; uint32_T bpIdx ; if ( u0 <=
bp0 [ 0U ] ) { iLeft = 0U ; frac = ( u0 - bp0 [ 0U ] ) / ( bp0 [ 1U ] - bp0 [
0U ] ) ; } else if ( u0 < bp0 [ maxIndex ] ) { bpIdx = maxIndex >> 1U ; iLeft
= 0U ; iRght = maxIndex ; while ( iRght - iLeft > 1U ) { if ( u0 < bp0 [
bpIdx ] ) { iRght = bpIdx ; } else { iLeft = bpIdx ; } bpIdx = ( iRght +
iLeft ) >> 1U ; } frac = ( u0 - bp0 [ iLeft ] ) / ( bp0 [ iLeft + 1U ] - bp0
[ iLeft ] ) ; } else { iLeft = maxIndex - 1U ; frac = ( u0 - bp0 [ maxIndex -
1U ] ) / ( bp0 [ maxIndex ] - bp0 [ maxIndex - 1U ] ) ; } return ( table [
iLeft + 1U ] - table [ iLeft ] ) * frac + table [ iLeft ] ; } real_T
look1_pbinlxpw ( real_T u0 , const real_T bp0 [ ] , const real_T table [ ] ,
uint32_T prevIndex [ ] , uint32_T maxIndex ) { real_T frac ; uint32_T iRght ;
uint32_T iLeft ; uint32_T bpIdx ; uint32_T found ; if ( u0 <= bp0 [ 0U ] ) {
bpIdx = 0U ; frac = ( u0 - bp0 [ 0U ] ) / ( bp0 [ 1U ] - bp0 [ 0U ] ) ; }
else if ( u0 < bp0 [ maxIndex ] ) { bpIdx = prevIndex [ 0U ] ; iLeft = 0U ;
iRght = maxIndex ; found = 0U ; while ( found == 0U ) { if ( u0 < bp0 [ bpIdx
] ) { iRght = bpIdx - 1U ; bpIdx = ( iRght + iLeft ) >> 1U ; } else if ( u0 <
bp0 [ bpIdx + 1U ] ) { found = 1U ; } else { iLeft = bpIdx + 1U ; bpIdx = (
iRght + iLeft ) >> 1U ; } } frac = ( u0 - bp0 [ bpIdx ] ) / ( bp0 [ bpIdx +
1U ] - bp0 [ bpIdx ] ) ; } else { bpIdx = maxIndex - 1U ; frac = ( u0 - bp0 [
maxIndex - 1U ] ) / ( bp0 [ maxIndex ] - bp0 [ maxIndex - 1U ] ) ; }
prevIndex [ 0U ] = bpIdx ; return ( table [ bpIdx + 1U ] - table [ bpIdx ] )
* frac + table [ bpIdx ] ; } void rt_ssGetBlockPath ( SimStruct * S , int_T
sysIdx , int_T blkIdx , char_T * * path ) { _ssGetBlockPath ( S , sysIdx ,
blkIdx , path ) ; } void rt_ssSet_slErrMsg ( SimStruct * S , void * diag ) {
if ( ! _ssIsErrorStatusAslErrMsg ( S ) ) { _ssSet_slErrMsg ( S , diag ) ; } }
void rt_ssReportDiagnosticAsWarning ( SimStruct * S , void * diag ) {
_ssReportDiagnosticAsWarning ( S , diag ) ; } static void mdlOutputs (
SimStruct * S , int_T tid ) { real_T B_22_123_0 ; real_T B_22_125_0 ; real_T
B_22_364_0 ; real_T rtb_B_22_4_0 ; real_T rtb_B_22_5_0 ; real_T rtb_B_22_7_0
; real_T rtb_B_22_13_0 ; real_T rtb_B_22_17_0 ; real_T rtb_B_22_42_0 ;
boolean_T rtb_B_22_78_0 ; real_T rtb_B_22_94_0 ; real_T rtb_B_22_97_0 ;
real_T rtb_B_22_115_0 ; real_T rtb_B_22_121_0 ; real_T rtb_B_22_150_0 ;
real_T rtb_B_22_273_0 ; real_T rtb_B_22_275_0 ; boolean_T rtb_B_22_277_0 ;
int32_T i ; boolean_T B_22_350_0_idx_0 ; boolean_T B_22_351_0_idx_0 ;
boolean_T B_22_350_0_idx_1 ; boolean_T B_22_351_0_idx_1 ;
B_TramWay_Charging_108V_full_test_T * _rtB ;
P_TramWay_Charging_108V_full_test_T * _rtP ;
X_TramWay_Charging_108V_full_test_T * _rtX ;
PrevZCX_TramWay_Charging_108V_full_test_T * _rtZCE ;
DW_TramWay_Charging_108V_full_test_T * _rtDW ; _rtDW = ( (
DW_TramWay_Charging_108V_full_test_T * ) ssGetRootDWork ( S ) ) ; _rtZCE = (
( PrevZCX_TramWay_Charging_108V_full_test_T * ) _ssGetPrevZCSigState ( S ) )
; _rtX = ( ( X_TramWay_Charging_108V_full_test_T * ) ssGetContStates ( S ) )
; _rtP = ( ( P_TramWay_Charging_108V_full_test_T * ) ssGetModelRtp ( S ) ) ;
_rtB = ( ( B_TramWay_Charging_108V_full_test_T * ) _ssGetModelBlockIO ( S ) )
; i = ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) { rtb_B_22_4_0 = _rtDW ->
itinit1_PreviousInput ; rtb_B_22_5_0 = _rtP -> P_8 * _rtDW ->
itinit1_PreviousInput ; rtb_B_22_7_0 = _rtP -> P_9 * _rtDW ->
Currentfilter_states ; _rtB -> B_22_10_0 = ( rtb_B_22_7_0 >
TramWay_Charging_108V_full_test_rtC ( S ) -> B_22_8_0 ) ; _rtB -> B_22_11_0 =
_rtDW -> itinit_PreviousInput ; if ( _rtDW -> inti_IC_LOADING != 0 ) { _rtDW
-> inti_DSTATE = _rtB -> B_22_11_0 ; if ( _rtDW -> inti_DSTATE >= _rtP ->
P_15 ) { _rtDW -> inti_DSTATE = _rtP -> P_15 ; } else { if ( _rtDW ->
inti_DSTATE <= _rtP -> P_16 ) { _rtDW -> inti_DSTATE = _rtP -> P_16 ; } } }
if ( ( _rtB -> B_22_10_0 > 0.0 ) && ( _rtDW -> inti_PrevResetState <= 0 ) ) {
_rtDW -> inti_DSTATE = _rtB -> B_22_11_0 ; if ( _rtDW -> inti_DSTATE >= _rtP
-> P_15 ) { _rtDW -> inti_DSTATE = _rtP -> P_15 ; } else { if ( _rtDW ->
inti_DSTATE <= _rtP -> P_16 ) { _rtDW -> inti_DSTATE = _rtP -> P_16 ; } } }
if ( _rtDW -> inti_DSTATE >= _rtP -> P_15 ) { _rtDW -> inti_DSTATE = _rtP ->
P_15 ; } else { if ( _rtDW -> inti_DSTATE <= _rtP -> P_16 ) { _rtDW ->
inti_DSTATE = _rtP -> P_16 ; } } rtb_B_22_13_0 = _rtP -> P_17 * _rtDW ->
inti_DSTATE ; if ( rtb_B_22_13_0 > rtb_B_22_5_0 ) { rtb_B_22_17_0 =
rtb_B_22_5_0 ; } else if ( rtb_B_22_13_0 < _rtB -> B_22_15_0 ) {
rtb_B_22_17_0 = _rtB -> B_22_15_0 ; } else { rtb_B_22_17_0 = rtb_B_22_13_0 ;
} if ( ! ( 1.000001 * rtb_B_22_5_0 * 0.97847358121330852 / 0.9999 <=
rtb_B_22_17_0 ) ) { rtb_B_22_5_0 = rtb_B_22_17_0 ; } rtb_B_22_17_0 = _rtP ->
P_21 * _rtDW -> itinit1_PreviousInput ; if ( ! ( rtb_B_22_13_0 >
rtb_B_22_17_0 ) ) { rtb_B_22_17_0 = - rtb_B_22_17_0 * 0.999 * 0.1 * 0.9999 ;
if ( ! ( rtb_B_22_13_0 < rtb_B_22_17_0 ) ) { rtb_B_22_17_0 = rtb_B_22_13_0 ;
} } switch ( ( int32_T ) _rtB -> B_22_22_0 ) { case 1 : rtb_B_22_17_0 = - ( (
real_T ) ( rtb_B_22_7_0 < TramWay_Charging_108V_full_test_rtC ( S ) ->
B_22_28_0 ) * _rtB -> B_22_23_0 ) * 0.0057492136185379808 * ( _rtB ->
B_22_23_0 * rtb_B_22_7_0 ) * ( 53.143999999999934 / ( _rtB -> B_22_23_0 *
rtb_B_22_17_0 + 5.3143999999999938 ) ) ; break ; case 2 : rtb_B_22_13_0 =
_rtB -> B_22_31_0 * _rtDW -> itinit1_PreviousInput ; rtb_B_22_17_0 = - ( (
real_T ) ( rtb_B_22_7_0 < TramWay_Charging_108V_full_test_rtC ( S ) ->
B_22_28_0 ) * _rtB -> B_22_31_0 ) * 0.0057492136185379808 * ( _rtB ->
B_22_31_0 * rtb_B_22_7_0 ) * rtb_B_22_13_0 / ( _rtB -> B_22_31_0 *
rtb_B_22_17_0 + rtb_B_22_13_0 * 0.1 ) ; break ; case 3 : rtb_B_22_17_0 = - (
( real_T ) ( rtb_B_22_7_0 < TramWay_Charging_108V_full_test_rtC ( S ) ->
B_22_28_0 ) * _rtB -> B_22_32_0 ) * 0.0057492136185379808 * ( _rtB ->
B_22_32_0 * rtb_B_22_7_0 ) * ( 53.143999999999934 / ( muDoubleScalarAbs (
_rtB -> B_22_32_0 * rtb_B_22_17_0 ) + 5.3143999999999938 ) ) ; break ;
default : rtb_B_22_17_0 = - ( ( real_T ) ( rtb_B_22_7_0 <
TramWay_Charging_108V_full_test_rtC ( S ) -> B_22_28_0 ) * _rtB -> B_22_33_0
) * 0.0057492136185379808 * ( _rtB -> B_22_33_0 * rtb_B_22_7_0 ) * (
53.143999999999934 / ( muDoubleScalarAbs ( _rtB -> B_22_33_0 * rtb_B_22_17_0
) + 5.3143999999999938 ) ) ; break ; } rtb_B_22_13_0 = _rtDW ->
DiscreteTimeIntegrator_DSTATE ; switch ( ( int32_T ) _rtB -> B_22_39_0 ) {
case 1 : rtb_B_22_42_0 = _rtDW -> DiscreteTimeIntegrator_DSTATE ; break ;
case 2 : if ( rtb_B_22_5_0 > _rtP -> P_1 ) { rtb_B_22_42_0 = _rtP -> P_1 ; }
else if ( rtb_B_22_5_0 < _rtP -> P_2 ) { rtb_B_22_42_0 = _rtP -> P_2 ; } else
{ rtb_B_22_42_0 = rtb_B_22_5_0 ; } rtb_B_22_42_0 = muDoubleScalarExp ( -
17.999996400000718 * rtb_B_22_42_0 ) * 8.3462561573407026 ; break ; case 3 :
rtb_B_22_42_0 = _rtDW -> DiscreteTimeIntegrator_DSTATE ; break ; default :
rtb_B_22_42_0 = _rtDW -> DiscreteTimeIntegrator_DSTATE ; break ; }
rtb_B_22_7_0 = ( ( ( ( - _rtB -> B_22_10_0 * 0.0057492136185379808 *
rtb_B_22_7_0 * _rtDW -> itinit1_PreviousInput / ( _rtDW ->
itinit1_PreviousInput - rtb_B_22_5_0 ) + - 0.0057492136185379808 * _rtDW ->
itinit1_PreviousInput / ( _rtDW -> itinit1_PreviousInput - rtb_B_22_5_0 ) *
rtb_B_22_5_0 ) + rtb_B_22_17_0 ) + rtb_B_22_42_0 ) + - 0.0 * rtb_B_22_5_0 ) +
_rtB -> B_22_3_0 ; if ( rtb_B_22_7_0 > _rtB -> B_22_2_0 ) { _rtB -> B_22_49_0
= _rtB -> B_22_2_0 ; } else if ( rtb_B_22_7_0 < _rtDW ->
Memory2_PreviousInput ) { _rtB -> B_22_49_0 = _rtDW -> Memory2_PreviousInput
; } else { _rtB -> B_22_49_0 = rtb_B_22_7_0 ; } _rtB -> B_22_51_0 =
look1_binlxpw ( _rtDW -> Memory_PreviousInput , _rtP -> P_32 , _rtP -> P_31 ,
8U ) ; ssCallAccelRunBlock ( S , 22 , 62 , SS_CALL_MDL_OUTPUTS ) ; _rtB ->
B_22_63_0 = _rtP -> P_53 * _rtB -> B_22_62_0 [ 45 ] ; _rtB -> B_22_64_0 =
_rtP -> P_54 * _rtB -> B_22_62_0 [ 46 ] ; _rtB -> B_22_65_0 = _rtP -> P_55 *
_rtB -> B_22_62_0 [ 47 ] ; ssCallAccelRunBlock ( S , 22 , 66 ,
SS_CALL_MDL_OUTPUTS ) ; _rtB -> B_22_67_0 = _rtP -> P_56 * _rtB -> B_22_62_0
[ 41 ] ; _rtB -> B_22_68_0 = _rtP -> P_57 * _rtB -> B_22_62_0 [ 39 ] ;
ssCallAccelRunBlock ( S , 22 , 69 , SS_CALL_MDL_OUTPUTS ) ; _rtB -> B_22_70_0
= _rtP -> P_58 * _rtB -> B_22_62_0 [ 49 ] ; _rtB -> B_22_71_0 = _rtP -> P_59
* _rtB -> B_22_62_0 [ 42 ] ; _rtB -> B_22_72_0 = _rtP -> P_60 * _rtB ->
B_22_62_0 [ 48 ] ; ssCallAccelRunBlock ( S , 22 , 73 , SS_CALL_MDL_OUTPUTS )
; rtb_B_22_78_0 = ( _rtB -> B_22_68_0 <= _rtB -> B_22_77_0 ) ; if ( !
rtb_B_22_78_0 ) { _rtB -> B_22_81_0 = _rtB -> B_22_76_0 ; } else { _rtB ->
B_22_81_0 = _rtDW -> Memory_PreviousInput_m ; } _rtB -> B_22_82_0 = ( ( _rtB
-> B_22_74_0 != 0.0 ) && ( _rtB -> B_22_75_0 != 0.0 ) && ( _rtB -> B_22_81_0
!= 0.0 ) && rtb_B_22_78_0 ) ; _rtB -> B_22_85_0 = ( ( ! _rtB -> B_22_82_0 )
&& ( _rtB -> B_22_74_0 != 0.0 ) && ( _rtB -> B_22_84_0 != 0.0 ) ) ; } _rtB ->
B_22_91_0 = look1_binlxpw ( muDoubleScalarRem ( ssGetT ( S ) - _rtB ->
B_22_87_0 , _rtB -> B_22_89_0 ) , _rtP -> P_69 , _rtP -> P_68 , 1U ) ; i =
ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) { rtb_B_22_94_0 = ( _rtB ->
B_22_92_0 + _rtB -> B_22_67_0 ) * _rtP -> P_71 ; } i = ssIsSampleHit ( S , 4
, 0 ) ; if ( i != 0 ) { _rtB -> B_22_95_0 = _rtDW -> UnitDelay2_DSTATE ; } i
= ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) { _rtB -> B_22_96_0 =
rtb_B_22_94_0 - _rtB -> B_22_95_0 ; } i = ssIsSampleHit ( S , 2 , 0 ) ; if (
i != 0 ) { rtb_B_22_97_0 = _rtP -> P_73 * _rtB -> B_22_96_0 ; _rtB ->
B_22_98_0 = _rtP -> P_74 * _rtB -> B_22_96_0 ; } i = ssIsSampleHit ( S , 1 ,
0 ) ; if ( i != 0 ) { _rtB -> B_22_99_0 = ! _rtB -> B_22_82_0 ; } i =
ssIsSampleHit ( S , 2 , 0 ) ; if ( i != 0 ) { if ( _rtB -> B_22_99_0 || (
_rtDW -> Integrator_PrevResetState != 0 ) ) { _rtDW -> Integrator_DSTATE =
_rtP -> P_76 ; } _rtB -> B_22_100_0 = _rtP -> P_75 * _rtB -> B_22_98_0 +
_rtDW -> Integrator_DSTATE ; rtb_B_22_7_0 = rtb_B_22_97_0 + _rtB ->
B_22_100_0 ; if ( rtb_B_22_7_0 > _rtP -> P_77 ) { _rtB -> B_22_102_0 = _rtP
-> P_77 ; } else if ( rtb_B_22_7_0 < _rtP -> P_78 ) { _rtB -> B_22_102_0 =
_rtP -> P_78 ; } else { _rtB -> B_22_102_0 = rtb_B_22_7_0 ; } } _rtB ->
B_22_103_0 = ( _rtB -> B_22_102_0 > _rtB -> B_22_91_0 ) ; i = ssIsSampleHit (
S , 1 , 0 ) ; if ( i != 0 ) { ssCallAccelRunBlock ( S , 22 , 104 ,
SS_CALL_MDL_OUTPUTS ) ; _rtB -> B_22_108_0 = ! _rtB -> B_22_82_0 ; _rtB ->
B_22_109_0 = ! _rtB -> B_22_82_0 ; } i = ssIsSampleHit ( S , 4 , 0 ) ; if ( i
!= 0 ) { _rtB -> B_22_110_0 = _rtDW -> UnitDelay15_DSTATE ; } i =
ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) { _rtB -> B_22_111_0 =
rtb_B_22_94_0 - _rtB -> B_22_110_0 ; } i = ssIsSampleHit ( S , 2 , 0 ) ; if (
i != 0 ) { _rtB -> B_22_112_0 = _rtP -> P_83 * _rtB -> B_22_111_0 ; if ( _rtB
-> B_22_108_0 || ( _rtDW -> Integrator_PrevResetState_k != 0 ) ) { _rtDW ->
Integrator_DSTATE_c = _rtP -> P_85 ; } _rtB -> B_22_113_0 = _rtP -> P_84 *
_rtB -> B_22_112_0 + _rtDW -> Integrator_DSTATE_c ; rtb_B_22_115_0 = _rtP ->
P_86 * _rtB -> B_22_111_0 + _rtB -> B_22_113_0 ; } i = ssIsSampleHit ( S , 4
, 0 ) ; if ( i != 0 ) { _rtB -> B_22_116_0 = _rtDW -> UnitDelay1_DSTATE ; } i
= ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) { _rtB -> B_22_117_0 =
rtb_B_22_94_0 - _rtB -> B_22_116_0 ; } i = ssIsSampleHit ( S , 2 , 0 ) ; if (
i != 0 ) { _rtB -> B_22_118_0 = _rtP -> P_88 * _rtB -> B_22_117_0 ; if ( _rtB
-> B_22_109_0 || ( _rtDW -> Integrator_PrevResetState_a != 0 ) ) { _rtDW ->
Integrator_DSTATE_a = _rtP -> P_90 ; } _rtB -> B_22_119_0 = _rtP -> P_89 *
_rtB -> B_22_118_0 + _rtDW -> Integrator_DSTATE_a ; rtb_B_22_121_0 = _rtP ->
P_91 * _rtB -> B_22_117_0 + _rtB -> B_22_119_0 ; if ( rtb_B_22_115_0 > _rtP
-> P_92 ) { _rtB -> B_22_122_0 = _rtP -> P_92 ; } else if ( rtb_B_22_115_0 <
_rtP -> P_93 ) { _rtB -> B_22_122_0 = _rtP -> P_93 ; } else { _rtB ->
B_22_122_0 = rtb_B_22_115_0 ; } } { real_T * * uBuffer = ( real_T * * ) &
_rtDW -> TransportDelay2_PWORK . TUbufferPtrs [ 0 ] ; real_T * * tBuffer = (
real_T * * ) & _rtDW -> TransportDelay2_PWORK . TUbufferPtrs [ 1 ] ; real_T
simTime = ssGetT ( S ) ; real_T tMinusDelay = simTime - _rtP -> P_94 ;
B_22_123_0 = TramWay_Charging_108V_full_test_acc_rt_TDelayInterpolate (
tMinusDelay , 0.0 , * tBuffer , * uBuffer , _rtDW -> TransportDelay2_IWORK .
CircularBufSize , & _rtDW -> TransportDelay2_IWORK . Last , _rtDW ->
TransportDelay2_IWORK . Tail , _rtDW -> TransportDelay2_IWORK . Head , _rtP
-> P_95 , 0 , ( boolean_T ) ( ssIsMinorTimeStep ( S ) && (
ssGetTimeOfLastOutput ( S ) == ssGetT ( S ) ) ) ) ; } i = ssIsSampleHit ( S ,
2 , 0 ) ; if ( i != 0 ) { if ( rtb_B_22_121_0 > _rtP -> P_96 ) { _rtB ->
B_22_124_0 = _rtP -> P_96 ; } else if ( rtb_B_22_121_0 < _rtP -> P_97 ) {
_rtB -> B_22_124_0 = _rtP -> P_97 ; } else { _rtB -> B_22_124_0 =
rtb_B_22_121_0 ; } } { real_T * * uBuffer = ( real_T * * ) & _rtDW ->
TransportDelay3_PWORK . TUbufferPtrs [ 0 ] ; real_T * * tBuffer = ( real_T *
* ) & _rtDW -> TransportDelay3_PWORK . TUbufferPtrs [ 1 ] ; real_T simTime =
ssGetT ( S ) ; real_T tMinusDelay = simTime - _rtP -> P_98 ; B_22_125_0 =
TramWay_Charging_108V_full_test_acc_rt_TDelayInterpolate ( tMinusDelay , 0.0
, * tBuffer , * uBuffer , _rtDW -> TransportDelay3_IWORK . CircularBufSize ,
& _rtDW -> TransportDelay3_IWORK . Last , _rtDW -> TransportDelay3_IWORK .
Tail , _rtDW -> TransportDelay3_IWORK . Head , _rtP -> P_99 , 0 , ( boolean_T
) ( ssIsMinorTimeStep ( S ) && ( ssGetTimeOfLastOutput ( S ) == ssGetT ( S )
) ) ) ; } i = ssIsSampleHit ( S , 2 , 0 ) ; if ( i != 0 ) { _rtB ->
B_22_131_0 = _rtB -> B_22_129_0 * _rtDW -> UnitDelay11_DSTATE ; if ( 0.0 >
_rtP -> P_109 ) { _rtB -> B_22_137_0 = _rtDW -> UnitDelay11_DSTATE * _rtB ->
B_22_133_0 * _rtP -> P_0 + _rtDW -> UnitDelay14_DSTATE ; } else { _rtB ->
B_22_137_0 = _rtB -> B_22_135_0 ; } _rtB -> B_22_138_0 = _rtDW ->
UnitDelay16_DSTATE ; ssCallAccelRunBlock ( S , 22 , 139 , SS_CALL_MDL_OUTPUTS
) ; } i = ssIsSampleHit ( S , 4 , 0 ) ; if ( i != 0 ) { _rtB -> B_22_141_0 =
0.0 - _rtDW -> UnitDelay15_DSTATE_l ; } i = ssIsSampleHit ( S , 2 , 0 ) ; if
( i != 0 ) { _rtB -> B_22_142_0 = _rtB -> B_22_131_0 + _rtB -> B_22_137_0 ; }
_rtB -> B_22_148_0 = look1_binlxpw ( muDoubleScalarRem ( ssGetT ( S ) - _rtB
-> B_22_144_0 , _rtB -> B_22_146_0 ) , _rtP -> P_114 , _rtP -> P_113 , 1U ) ;
i = ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) { rtb_B_22_150_0 = _rtB ->
B_22_149_0 - _rtB -> B_22_68_0 ; _rtB -> B_22_151_0 = _rtP -> P_116 *
rtb_B_22_150_0 ; _rtB -> B_22_152_0 = ! _rtB -> B_22_85_0 ; } if (
ssIsMajorTimeStep ( S ) != 0 ) { rtb_B_22_78_0 = false ; B_22_351_0_idx_0 = (
( ( _rtZCE -> Integrator_Reset_ZCE == POS_ZCSIG ) != ( int32_T ) _rtB ->
B_22_152_0 ) && ( _rtZCE -> Integrator_Reset_ZCE != UNINITIALIZED_ZCSIG ) ) ;
_rtZCE -> Integrator_Reset_ZCE = _rtB -> B_22_152_0 ; if ( B_22_351_0_idx_0
|| _rtB -> B_22_152_0 ) { rtb_B_22_78_0 = true ; _rtX -> Integrator_CSTATE =
_rtP -> P_117 ; } if ( rtb_B_22_78_0 ) {
ssSetBlockStateForSolverChangedAtMajorStep ( S ) ; } } rtb_B_22_7_0 = _rtB ->
B_22_151_0 + _rtX -> Integrator_CSTATE ; if ( rtb_B_22_7_0 > _rtP -> P_118 )
{ _rtB -> B_22_155_0 = _rtP -> P_118 ; } else if ( rtb_B_22_7_0 < _rtP ->
P_119 ) { _rtB -> B_22_155_0 = _rtP -> P_119 ; } else { _rtB -> B_22_155_0 =
rtb_B_22_7_0 ; } _rtB -> B_22_156_0 = ( _rtB -> B_22_155_0 > _rtB ->
B_22_148_0 ) ; { real_T * * uBuffer = ( real_T * * ) & _rtDW ->
TransportDelay2_PWORK_d . TUbufferPtrs [ 0 ] ; real_T * * tBuffer = ( real_T
* * ) & _rtDW -> TransportDelay2_PWORK_d . TUbufferPtrs [ 1 ] ; real_T
simTime = ssGetT ( S ) ; real_T tMinusDelay = simTime - _rtP -> P_120 ; _rtB
-> B_22_157_0 = TramWay_Charging_108V_full_test_acc_rt_TDelayInterpolate (
tMinusDelay , 0.0 , * tBuffer , * uBuffer , _rtDW -> TransportDelay2_IWORK_h
. CircularBufSize , & _rtDW -> TransportDelay2_IWORK_h . Last , _rtDW ->
TransportDelay2_IWORK_h . Tail , _rtDW -> TransportDelay2_IWORK_h . Head ,
_rtP -> P_121 , 0 , ( boolean_T ) ( ssIsMinorTimeStep ( S ) && (
ssGetTimeOfLastOutput ( S ) == ssGetT ( S ) ) ) ) ; } _rtB -> B_22_158_0 = (
_rtB -> B_22_155_0 > _rtB -> B_22_157_0 ) ; { real_T * * uBuffer = ( real_T *
* ) & _rtDW -> TransportDelay3_PWORK_e . TUbufferPtrs [ 0 ] ; real_T * *
tBuffer = ( real_T * * ) & _rtDW -> TransportDelay3_PWORK_e . TUbufferPtrs [
1 ] ; real_T simTime = ssGetT ( S ) ; real_T tMinusDelay = simTime - _rtP ->
P_122 ; _rtB -> B_22_159_0 =
TramWay_Charging_108V_full_test_acc_rt_TDelayInterpolate ( tMinusDelay , 0.0
, * tBuffer , * uBuffer , _rtDW -> TransportDelay3_IWORK_a . CircularBufSize
, & _rtDW -> TransportDelay3_IWORK_a . Last , _rtDW ->
TransportDelay3_IWORK_a . Tail , _rtDW -> TransportDelay3_IWORK_a . Head ,
_rtP -> P_123 , 0 , ( boolean_T ) ( ssIsMinorTimeStep ( S ) && (
ssGetTimeOfLastOutput ( S ) == ssGetT ( S ) ) ) ) ; } _rtB -> B_22_160_0 = (
_rtB -> B_22_155_0 > _rtB -> B_22_159_0 ) ; i = ssIsSampleHit ( S , 1 , 0 ) ;
if ( i != 0 ) { ssCallAccelRunBlock ( S , 22 , 161 , SS_CALL_MDL_OUTPUTS ) ;
_rtB -> B_22_165_0 = _rtP -> P_127 * rtb_B_22_150_0 ; } if ( _rtB ->
B_22_85_0 ) { if ( _rtB -> B_22_85_0 ) { _rtB -> B_22_262_0 = _rtB ->
B_22_156_0 ; } else { _rtB -> B_22_262_0 = _rtB -> B_22_162_0 ; } } else if (
_rtB -> B_22_82_0 ) { _rtB -> B_22_262_0 = _rtB -> B_22_103_0 ; } else { _rtB
-> B_22_262_0 = _rtB -> B_22_105_0 ; } if ( _rtB -> B_22_85_0 ) { if ( _rtB
-> B_22_85_0 ) { _rtB -> B_22_265_0 = _rtB -> B_22_158_0 ; } else { _rtB ->
B_22_265_0 = _rtB -> B_22_163_0 ; } } else if ( _rtB -> B_22_82_0 ) { _rtB ->
B_22_265_0 = ( _rtB -> B_22_122_0 > B_22_123_0 ) ; } else { _rtB ->
B_22_265_0 = _rtB -> B_22_106_0 ; } if ( _rtB -> B_22_85_0 ) { if ( _rtB ->
B_22_85_0 ) { _rtB -> B_22_268_0 = _rtB -> B_22_160_0 ; } else { _rtB ->
B_22_268_0 = _rtB -> B_22_164_0 ; } } else if ( _rtB -> B_22_82_0 ) { _rtB ->
B_22_268_0 = ( _rtB -> B_22_124_0 > B_22_125_0 ) ; } else { _rtB ->
B_22_268_0 = _rtB -> B_22_107_0 ; } i = ssIsSampleHit ( S , 1 , 0 ) ; if ( i
!= 0 ) { rtb_B_22_273_0 = _rtDW -> Memory_PreviousInput_k ; _rtB ->
B_22_274_0 = _rtP -> P_130 * _rtB -> B_22_62_0 [ 38 ] ; rtb_B_22_275_0 =
muDoubleScalarAbs ( _rtB -> B_22_274_0 ) ; rtb_B_22_277_0 = ( rtb_B_22_275_0
< _rtB -> B_22_276_0 ) ; _rtB -> B_22_279_0 = ( _rtDW ->
Memory_PreviousInput_k > _rtB -> B_22_278_0 ) ; if ( ( ! _rtB -> B_22_279_0 )
&& ( _rtZCE -> Delay_Reset_ZCE != ZERO_ZCSIG ) ) { for ( i = 0 ; i < 800 ; i
++ ) { _rtDW -> Delay_DSTATE [ i ] = _rtP -> P_134 ; } _rtDW -> CircBufIdx =
0U ; } _rtZCE -> Delay_Reset_ZCE = _rtB -> B_22_279_0 ; if ( _rtDW ->
Delay_DSTATE [ _rtDW -> CircBufIdx ] > _rtP -> P_136 ) { rtb_B_22_94_0 = (
rtb_B_22_277_0 && _rtB -> B_22_279_0 && ( _rtB -> B_22_280_0 != 0.0 ) ) ; }
else { rtb_B_22_94_0 = _rtB -> B_22_282_0 ; } if ( rtb_B_22_94_0 > _rtP ->
P_138 ) { _rtB -> B_22_286_0 = _rtDW -> Memory_PreviousInput_k ; } else {
_rtB -> B_22_286_0 = _rtDW -> Memory1_PreviousInput ; } if ( ( _rtB ->
B_22_286_0 < _rtDW -> Memory2_PreviousInput_h + _rtB -> B_22_287_0 ) && (
_rtB -> B_22_286_0 > _rtDW -> Memory2_PreviousInput_h - _rtB -> B_22_290_0 )
) { _rtB -> B_22_294_0 = _rtDW -> Memory2_PreviousInput_h ; } else { _rtB ->
B_22_294_0 = _rtB -> B_22_286_0 ; } _rtB -> B_22_296_0 = _rtB -> B_22_295_0 -
_rtB -> B_22_294_0 ; _rtB -> B_22_297_0 = _rtP -> P_142 * _rtB -> B_22_296_0
; } if ( ssIsMajorTimeStep ( S ) != 0 ) { rtb_B_22_78_0 = false ;
B_22_351_0_idx_0 = ( ( ( _rtZCE -> Integrator_Reset_ZCE_h == POS_ZCSIG ) != (
int32_T ) _rtB -> B_22_299_0 ) && ( _rtZCE -> Integrator_Reset_ZCE_h !=
UNINITIALIZED_ZCSIG ) ) ; _rtZCE -> Integrator_Reset_ZCE_h = _rtB ->
B_22_299_0 ; if ( B_22_351_0_idx_0 || _rtB -> B_22_299_0 ) { rtb_B_22_78_0 =
true ; _rtX -> Integrator_CSTATE_k = _rtP -> P_144 ; } if ( rtb_B_22_78_0 ) {
ssSetBlockStateForSolverChangedAtMajorStep ( S ) ; } } _rtB -> B_22_301_0 =
_rtB -> B_22_297_0 + _rtX -> Integrator_CSTATE_k ; i = ssIsSampleHit ( S , 1
, 0 ) ; if ( i != 0 ) { ssCallAccelRunBlock ( S , 22 , 302 ,
SS_CALL_MDL_OUTPUTS ) ; } i = ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) {
_rtB -> B_22_330_0 = _rtP -> P_148 ; } rtb_B_22_94_0 = ssGetT ( S ) + _rtB ->
B_22_330_0 ; i = ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) { _rtB ->
B_22_332_0 = _rtP -> P_149 ; } rtb_B_22_94_0 = look1_pbinlxpw ( _rtP -> P_150
* muDoubleScalarRem ( rtb_B_22_94_0 , _rtB -> B_22_332_0 ) , _rtP -> P_152 ,
_rtP -> P_151 , & _rtDW -> m_bpIndex , 2U ) ; i = ssIsSampleHit ( S , 1 , 0 )
; if ( i != 0 ) { _rtB -> B_22_336_0 = _rtP -> P_153 ; } _rtB -> B_22_341_0 =
( ( rtb_B_22_94_0 - _rtB -> B_22_336_0 ) * _rtB -> B_22_339_0 + _rtB ->
B_22_328_0 [ 0 ] ) + _rtB -> B_22_339_0 ; i = ssIsSampleHit ( S , 1 , 0 ) ;
if ( i != 0 ) { _rtB -> B_22_343_0 [ 0 ] = _rtP -> P_156 [ 0 ] ; _rtB ->
B_22_343_0 [ 1 ] = _rtP -> P_156 [ 1 ] ; _rtB -> B_22_343_0 [ 2 ] = _rtP ->
P_156 [ 2 ] ; } rtb_B_22_97_0 = _rtP -> P_158 * _rtB -> B_22_344_0 ; if (
_rtB -> B_22_301_0 > _rtP -> P_159 ) { rtb_B_22_115_0 = _rtP -> P_159 ; }
else if ( _rtB -> B_22_301_0 < _rtP -> P_160 ) { rtb_B_22_115_0 = _rtP ->
P_160 ; } else { rtb_B_22_115_0 = _rtB -> B_22_301_0 ; } _rtB -> B_22_349_0 [
0 ] = muDoubleScalarSin ( ( _rtX -> Integrator_CSTATE_l + _rtB -> B_22_343_0
[ 0 ] ) + rtb_B_22_97_0 ) * rtb_B_22_115_0 ; rtb_B_22_78_0 = ( _rtB ->
B_22_349_0 [ 0 ] >= _rtB -> B_22_341_0 ) ; B_22_351_0_idx_0 = ! rtb_B_22_78_0
; B_22_350_0_idx_0 = rtb_B_22_78_0 ; _rtB -> B_22_349_0 [ 1 ] =
muDoubleScalarSin ( ( _rtX -> Integrator_CSTATE_l + _rtB -> B_22_343_0 [ 1 ]
) + rtb_B_22_97_0 ) * rtb_B_22_115_0 ; rtb_B_22_78_0 = ( _rtB -> B_22_349_0 [
1 ] >= _rtB -> B_22_341_0 ) ; B_22_351_0_idx_1 = ! rtb_B_22_78_0 ;
B_22_350_0_idx_1 = rtb_B_22_78_0 ; _rtB -> B_22_349_0 [ 2 ] =
muDoubleScalarSin ( ( _rtX -> Integrator_CSTATE_l + _rtB -> B_22_343_0 [ 2 ]
) + rtb_B_22_97_0 ) * rtb_B_22_115_0 ; rtb_B_22_78_0 = ( _rtB -> B_22_349_0 [
2 ] >= _rtB -> B_22_341_0 ) ; _rtB -> B_22_352_0 [ 0 ] = B_22_350_0_idx_0 ;
_rtB -> B_22_352_0 [ 1 ] = B_22_351_0_idx_0 ; _rtB -> B_22_352_0 [ 2 ] =
B_22_350_0_idx_1 ; _rtB -> B_22_352_0 [ 3 ] = B_22_351_0_idx_1 ; _rtB ->
B_22_352_0 [ 4 ] = rtb_B_22_78_0 ; _rtB -> B_22_352_0 [ 5 ] = ! rtb_B_22_78_0
; i = ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) { ssCallAccelRunBlock ( S ,
22 , 353 , SS_CALL_MDL_OUTPUTS ) ; } _rtB -> B_22_354_0 = _rtP -> P_161 *
_rtB -> B_22_327_0 ; i = ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) { _rtB
-> B_22_355_0 = _rtP -> P_162 * _rtB -> B_22_296_0 ; } if ( _rtB ->
B_22_298_0 > _rtP -> P_163 ) { _rtB -> B_22_356_0 [ 0 ] = _rtB -> B_22_352_0
[ 0 ] ; _rtB -> B_22_356_0 [ 1 ] = _rtB -> B_22_352_0 [ 1 ] ; _rtB ->
B_22_356_0 [ 2 ] = _rtB -> B_22_352_0 [ 2 ] ; _rtB -> B_22_356_0 [ 3 ] = _rtB
-> B_22_352_0 [ 3 ] ; _rtB -> B_22_356_0 [ 4 ] = _rtB -> B_22_352_0 [ 4 ] ;
_rtB -> B_22_356_0 [ 5 ] = _rtB -> B_22_352_0 [ 5 ] ; } else { _rtB ->
B_22_356_0 [ 0 ] = _rtB -> B_22_326_0 ; _rtB -> B_22_356_0 [ 1 ] = _rtB ->
B_22_326_0 ; _rtB -> B_22_356_0 [ 2 ] = _rtB -> B_22_326_0 ; _rtB ->
B_22_356_0 [ 3 ] = _rtB -> B_22_326_0 ; _rtB -> B_22_356_0 [ 4 ] = _rtB ->
B_22_326_0 ; _rtB -> B_22_356_0 [ 5 ] = _rtB -> B_22_326_0 ; } i =
ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) { ssCallAccelRunBlock ( S , 22 ,
362 , SS_CALL_MDL_OUTPUTS ) ; if ( rtb_B_22_275_0 > rtb_B_22_273_0 ) {
B_22_364_0 = rtb_B_22_275_0 ; } else { B_22_364_0 = rtb_B_22_273_0 ; } { if (
( _rtDW -> HiddenToAsyncQueue_InsertedFor_Switch_at_outport_0_PWORK .
AQHandles || _rtDW ->
HiddenToAsyncQueue_InsertedFor_Switch_at_outport_0_PWORK . SlioLTF ) &&
ssGetLogOutput ( S ) ) { sdiSlioSdiWriteSignal ( _rtDW ->
HiddenToAsyncQueue_InsertedFor_Switch_at_outport_0_PWORK . AQHandles , _rtDW
-> HiddenToAsyncQueue_InsertedFor_Switch_at_outport_0_PWORK . SlioLTF , 0 ,
ssGetTaskTime ( S , 1 ) , ( void * ) & B_22_364_0 ) ; } } if ( rtb_B_22_277_0
) { _rtB -> B_22_368_0 = _rtB -> B_22_366_0 ; } else { _rtB -> B_22_368_0 =
B_22_364_0 ; } rtb_B_22_4_0 *= _rtP -> P_166 ; rtb_B_22_7_0 = ( 1.0 -
rtb_B_22_5_0 / rtb_B_22_4_0 ) * 100.0 ; if ( rtb_B_22_7_0 > _rtP -> P_167 ) {
_rtB -> B_22_374_0 = _rtP -> P_167 ; } else if ( rtb_B_22_7_0 < _rtP -> P_168
) { _rtB -> B_22_374_0 = _rtP -> P_168 ; } else { _rtB -> B_22_374_0 =
rtb_B_22_7_0 ; } _rtB -> B_22_375_0 = _rtP -> P_169 * _rtB -> B_22_62_0 [ 44
] ; _rtB -> B_22_377_0 = _rtB -> B_22_49_0 - _rtP -> P_170 * _rtB ->
B_22_375_0 ; ssCallAccelRunBlock ( S , 22 , 378 , SS_CALL_MDL_OUTPUTS ) ;
_rtB -> B_22_393_0 = ( ( real_T ) ( _rtB -> B_22_375_0 <
TramWay_Charging_108V_full_test_rtC ( S ) -> B_22_387_0 ) * _rtP -> P_173 -
rtb_B_22_13_0 ) * muDoubleScalarAbs ( _rtB -> B_22_375_0 ) * _rtP -> P_174 ;
_rtB -> B_22_394_0 = _rtP -> P_175 * rtb_B_22_5_0 ; _rtB -> B_22_395_0 = _rtP
-> P_176 * _rtB -> B_22_375_0 ; } i = ssIsSampleHit ( S , 2 , 0 ) ; if ( i !=
0 ) { _rtB -> B_22_402_0 = _rtB -> B_22_400_0 * _rtDW -> UnitDelay11_DSTATE_h
; _rtB -> B_22_406_0 = _rtDW -> UnitDelay11_DSTATE_h * _rtB -> B_22_399_0 *
_rtP -> P_180 + _rtDW -> UnitDelay14_DSTATE_d ; _rtB -> B_22_407_0 = _rtB ->
B_22_402_0 + _rtB -> B_22_406_0 ; ssCallAccelRunBlock ( S , 22 , 408 ,
SS_CALL_MDL_OUTPUTS ) ; } i = ssIsSampleHit ( S , 4 , 0 ) ; if ( i != 0 ) {
_rtB -> B_22_410_0 = 0.0 - _rtDW -> UnitDelay15_DSTATE_e ; } i =
ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) { _rtB -> B_22_465_0 = _rtP ->
P_201 * _rtB -> B_22_62_0 [ 50 ] ; _rtB -> B_22_484_0 [ 0 ] = _rtP -> P_202 [
0 ] * _rtB -> B_22_62_0 [ 53 ] ; _rtB -> B_22_484_0 [ 1 ] = _rtP -> P_202 [ 1
] * _rtB -> B_22_62_0 [ 57 ] ; _rtB -> B_22_485_0 [ 0 ] = _rtP -> P_203 [ 0 ]
* _rtB -> B_22_62_0 [ 52 ] ; _rtB -> B_22_485_0 [ 1 ] = _rtP -> P_203 [ 1 ] *
_rtB -> B_22_62_0 [ 56 ] ; _rtB -> B_22_486_0 [ 0 ] = _rtP -> P_204 [ 0 ] *
_rtB -> B_22_62_0 [ 51 ] ; _rtB -> B_22_486_0 [ 1 ] = _rtP -> P_204 [ 1 ] *
_rtB -> B_22_62_0 [ 55 ] ; _rtB -> B_22_487_0 [ 0 ] = _rtP -> P_205 [ 0 ] *
_rtB -> B_22_62_0 [ 54 ] ; _rtB -> B_22_487_0 [ 1 ] = _rtP -> P_205 [ 1 ] *
_rtB -> B_22_62_0 [ 58 ] ; } i = ssIsSampleHit ( S , 3 , 0 ) ; if ( i != 0 )
{ ssCallAccelRunBlock ( S , 22 , 488 , SS_CALL_MDL_OUTPUTS ) ; } i =
ssIsSampleHit ( S , 1 , 0 ) ; if ( i != 0 ) { if ( _rtB -> B_22_490_0 > 0.0 )
{ ssCallAccelRunBlock ( S , 18 , 0 , SS_CALL_MDL_OUTPUTS ) ; if (
ssIsMajorTimeStep ( S ) != 0 ) { srUpdateBC ( _rtDW ->
StoreData_SubsysRanBC_k ) ; } } if ( _rtB -> B_22_499_0 > 0.0 ) {
ssCallAccelRunBlock ( S , 19 , 0 , SS_CALL_MDL_OUTPUTS ) ; if (
ssIsMajorTimeStep ( S ) != 0 ) { srUpdateBC ( _rtDW ->
StoreData_SubsysRanBC_bn ) ; } } if ( _rtB -> B_22_508_0 > 0.0 ) {
ssCallAccelRunBlock ( S , 20 , 0 , SS_CALL_MDL_OUTPUTS ) ; if (
ssIsMajorTimeStep ( S ) != 0 ) { srUpdateBC ( _rtDW ->
StoreData_SubsysRanBC_b ) ; } } if ( _rtB -> B_22_517_0 > 0.0 ) {
ssCallAccelRunBlock ( S , 21 , 0 , SS_CALL_MDL_OUTPUTS ) ; if (
ssIsMajorTimeStep ( S ) != 0 ) { srUpdateBC ( _rtDW -> StoreData_SubsysRanBC
) ; } } _rtB -> B_22_615_0 = _rtP -> P_220 * _rtB -> B_22_62_0 [ 43 ] ; _rtB
-> B_22_616_0 = _rtP -> P_221 * _rtB -> B_22_62_0 [ 37 ] ;
ssCallAccelRunBlock ( S , 22 , 617 , SS_CALL_MDL_OUTPUTS ) ; }
UNUSED_PARAMETER ( tid ) ; } static void mdlOutputsTID6 ( SimStruct * S ,
int_T tid ) { real_T rtb_B_22_531_0 ; boolean_T rtb_B_22_533_0 ;
B_TramWay_Charging_108V_full_test_T * _rtB ;
P_TramWay_Charging_108V_full_test_T * _rtP ; _rtP = ( (
P_TramWay_Charging_108V_full_test_T * ) ssGetModelRtp ( S ) ) ; _rtB = ( (
B_TramWay_Charging_108V_full_test_T * ) _ssGetModelBlockIO ( S ) ) ; memcpy (
& _rtB -> B_22_0_0 [ 0 ] , & _rtP -> P_3 [ 0 ] , 37U * sizeof ( real_T ) ) ;
_rtB -> B_22_1_0 = _rtP -> P_4 ; _rtB -> B_22_2_0 = _rtP -> P_5 ; _rtB ->
B_22_3_0 = _rtP -> P_6 ; _rtB -> B_22_15_0 = _rtP -> P_18 ; _rtB -> B_22_22_0
= _rtP -> P_19 ; _rtB -> B_22_23_0 = _rtP -> P_20 ; _rtB -> B_22_31_0 = _rtP
-> P_23 ; _rtB -> B_22_32_0 = _rtP -> P_24 ; _rtB -> B_22_33_0 = _rtP -> P_25
; _rtB -> B_22_39_0 = _rtP -> P_26 ; _rtB -> B_22_52_0 = _rtP -> P_33 ; _rtB
-> B_22_53_0 = _rtP -> P_34 ; _rtB -> B_22_54_0 = _rtP -> P_35 ; _rtB ->
B_22_55_0 = _rtP -> P_36 ; _rtB -> B_22_56_0 = _rtP -> P_37 ; _rtB ->
B_22_57_0 = _rtP -> P_38 ; _rtB -> B_22_58_0 = _rtP -> P_39 ; _rtB ->
B_22_59_0 = _rtP -> P_40 ; _rtB -> B_22_60_0 = _rtP -> P_41 ; _rtB ->
B_22_61_0 = _rtP -> P_42 ; _rtB -> B_22_74_0 = _rtP -> P_61 ; _rtB ->
B_22_75_0 = _rtP -> P_62 ; _rtB -> B_22_76_0 = _rtP -> P_63 ; _rtB ->
B_22_77_0 = _rtP -> P_64 ; _rtB -> B_22_84_0 = _rtP -> P_66 ; _rtB ->
B_22_89_0 = _rtP -> P_67 ; _rtB -> B_22_92_0 = _rtP -> P_70 ; _rtB ->
B_22_105_0 = _rtP -> P_79 ; _rtB -> B_22_106_0 = _rtP -> P_80 ; _rtB ->
B_22_107_0 = _rtP -> P_81 ; if ( 0.0 > _rtP -> P_103 ) { _rtB -> B_22_129_0 =
_rtP -> P_101 ; } else { _rtB -> B_22_129_0 = _rtP -> P_102 ; } if ( 0.0 >
_rtP -> P_106 ) { _rtB -> B_22_133_0 = _rtP -> P_100 ; } else { _rtB ->
B_22_133_0 = _rtP -> P_105 ; } _rtB -> B_22_135_0 = _rtP -> P_108 ; _rtB ->
B_22_146_0 = _rtP -> P_112 ; _rtB -> B_22_149_0 = _rtP -> P_115 ; _rtB ->
B_22_162_0 = _rtP -> P_124 ; _rtB -> B_22_163_0 = _rtP -> P_125 ; _rtB ->
B_22_164_0 = _rtP -> P_126 ; _rtB -> B_22_276_0 = _rtP -> P_131 ; _rtB ->
B_22_278_0 = _rtP -> P_132 ; _rtB -> B_22_280_0 = _rtP -> P_133 ; _rtB ->
B_22_282_0 = _rtP -> P_135 ; _rtB -> B_22_287_0 = _rtP -> P_139 ; _rtB ->
B_22_290_0 = _rtP -> P_140 ; _rtB -> B_22_295_0 = _rtP -> P_141 ; _rtB ->
B_22_298_0 = _rtP -> P_143 ; _rtB -> B_22_299_0 = ! ( _rtB -> B_22_298_0 !=
0.0 ) ; _rtB -> B_22_326_0 = _rtP -> P_145 ; _rtB -> B_22_327_0 = _rtP ->
P_146 ; _rtB -> B_22_328_0 [ 0 ] = _rtP -> P_147 [ 0 ] ; _rtB -> B_22_328_0 [
1 ] = _rtP -> P_147 [ 1 ] ; _rtB -> B_22_339_0 = ( _rtB -> B_22_328_0 [ 1 ] -
_rtB -> B_22_328_0 [ 0 ] ) * _rtP -> P_154 ; _rtB -> B_22_344_0 = _rtP ->
P_157 ; _rtB -> B_22_366_0 = _rtP -> P_164 ; _rtB -> B_22_367_0 = _rtP ->
P_165 ; _rtB -> B_22_385_0 = _rtP -> P_171 ; _rtB -> B_22_399_0 = _rtP ->
P_177 ; _rtB -> B_22_400_0 = _rtP -> P_178 ; switch ( ( int32_T ) _rtP ->
P_185 ) { case 1 : _rtB -> B_22_417_0 = _rtP -> P_183 ; break ; case 2 : _rtB
-> B_22_417_0 = _rtP -> P_184 ; break ; default : _rtB -> B_22_417_0 = _rtP
-> P_183 ; break ; } switch ( ( int32_T ) _rtP -> P_188 ) { case 1 : _rtB ->
B_22_424_0 = _rtP -> P_187 ; break ; case 2 : _rtB -> B_22_424_0 = _rtP ->
P_186 ; break ; default : _rtB -> B_22_424_0 = _rtP -> P_187 ; break ; }
switch ( ( int32_T ) _rtP -> P_185 ) { case 1 : _rtB -> B_22_433_0 = _rtP ->
P_189 ; break ; case 2 : _rtB -> B_22_433_0 = _rtP -> P_190 ; break ; default
: _rtB -> B_22_433_0 = _rtP -> P_189 ; break ; } switch ( ( int32_T ) _rtP ->
P_193 ) { case 1 : _rtB -> B_22_440_0 = _rtP -> P_192 ; break ; case 2 : _rtB
-> B_22_440_0 = _rtP -> P_191 ; break ; default : _rtB -> B_22_440_0 = _rtP
-> P_192 ; break ; } switch ( ( int32_T ) _rtP -> P_200 ) { case 1 : _rtB ->
B_22_457_0 = _rtP -> P_196 ; _rtB -> B_22_458_0 = _rtP -> P_199 ; break ;
case 2 : _rtB -> B_22_457_0 = _rtP -> P_197 ; _rtB -> B_22_458_0 = _rtP ->
P_194 ; break ; default : _rtB -> B_22_457_0 = _rtP -> P_198 ; _rtB ->
B_22_458_0 = _rtP -> P_195 ; break ; } _rtB -> B_22_490_0 = _rtP -> P_207 ;
_rtB -> B_22_499_0 = _rtP -> P_208 ; _rtB -> B_22_508_0 = _rtP -> P_209 ;
_rtB -> B_22_517_0 = _rtP -> P_210 ; switch ( ( int32_T ) _rtP -> P_206 ) {
case 0 : rtb_B_22_531_0 = _rtP -> P_211 ; break ; case 1 : rtb_B_22_531_0 =
_rtP -> P_212 ; break ; case 2 : rtb_B_22_531_0 = _rtP -> P_213 ; break ;
case 3 : rtb_B_22_531_0 = _rtP -> P_214 ; break ; case 4 : rtb_B_22_531_0 =
_rtP -> P_215 ; break ; default : rtb_B_22_531_0 = _rtP -> P_211 ; break ; }
rtb_B_22_533_0 = ( rtb_B_22_531_0 == _rtP -> P_216 ) ; _rtB -> B_22_534_0 =
rtb_B_22_533_0 ; _rtB -> B_22_538_0 = rtb_B_22_533_0 ; _rtB -> B_22_542_0 =
rtb_B_22_533_0 ; rtb_B_22_533_0 = ( rtb_B_22_531_0 == _rtP -> P_217 ) ; _rtB
-> B_22_554_0 = rtb_B_22_533_0 ; _rtB -> B_22_558_0 = rtb_B_22_533_0 ; _rtB
-> B_22_562_0 = rtb_B_22_533_0 ; rtb_B_22_533_0 = ( rtb_B_22_531_0 == _rtP ->
P_218 ) ; _rtB -> B_22_574_0 = rtb_B_22_533_0 ; _rtB -> B_22_578_0 =
rtb_B_22_533_0 ; _rtB -> B_22_582_0 = rtb_B_22_533_0 ; rtb_B_22_533_0 = (
rtb_B_22_531_0 == _rtP -> P_219 ) ; _rtB -> B_22_594_0 = rtb_B_22_533_0 ;
_rtB -> B_22_598_0 = rtb_B_22_533_0 ; _rtB -> B_22_602_0 = rtb_B_22_533_0 ;
UNUSED_PARAMETER ( tid ) ; }
#define MDL_UPDATE
static void mdlUpdate ( SimStruct * S , int_T tid ) { int32_T isHit ;
B_TramWay_Charging_108V_full_test_T * _rtB ;
P_TramWay_Charging_108V_full_test_T * _rtP ;
DW_TramWay_Charging_108V_full_test_T * _rtDW ; _rtDW = ( (
DW_TramWay_Charging_108V_full_test_T * ) ssGetRootDWork ( S ) ) ; _rtP = ( (
P_TramWay_Charging_108V_full_test_T * ) ssGetModelRtp ( S ) ) ; _rtB = ( (
B_TramWay_Charging_108V_full_test_T * ) _ssGetModelBlockIO ( S ) ) ; isHit =
ssIsSampleHit ( S , 1 , 0 ) ; if ( isHit != 0 ) { _rtDW ->
itinit1_PreviousInput = _rtB -> B_22_385_0 ; _rtDW -> Currentfilter_states =
( _rtB -> B_22_375_0 - _rtP -> P_10 [ 1 ] * _rtDW -> Currentfilter_states ) /
_rtP -> P_10 [ 0 ] ; _rtDW -> itinit_PreviousInput = _rtB -> B_22_394_0 ;
_rtDW -> inti_IC_LOADING = 0U ; _rtDW -> inti_DSTATE += _rtP -> P_14 * _rtB
-> B_22_375_0 ; if ( _rtDW -> inti_DSTATE >= _rtP -> P_15 ) { _rtDW ->
inti_DSTATE = _rtP -> P_15 ; } else { if ( _rtDW -> inti_DSTATE <= _rtP ->
P_16 ) { _rtDW -> inti_DSTATE = _rtP -> P_16 ; } } if ( _rtB -> B_22_10_0 >
0.0 ) { _rtDW -> inti_PrevResetState = 1 ; } else if ( _rtB -> B_22_10_0 <
0.0 ) { _rtDW -> inti_PrevResetState = - 1 ; } else if ( _rtB -> B_22_10_0 ==
0.0 ) { _rtDW -> inti_PrevResetState = 0 ; } else { _rtDW ->
inti_PrevResetState = 2 ; } _rtDW -> DiscreteTimeIntegrator_DSTATE += _rtP ->
P_27 * _rtB -> B_22_393_0 ; _rtDW -> Memory2_PreviousInput = _rtB ->
B_22_395_0 ; _rtDW -> Memory_PreviousInput = _rtB -> B_22_465_0 ;
ssCallAccelRunBlock ( S , 22 , 62 , SS_CALL_MDL_UPDATE ) ; _rtDW ->
Memory_PreviousInput_m = _rtB -> B_22_81_0 ; } isHit = ssIsSampleHit ( S , 4
, 0 ) ; if ( isHit != 0 ) { _rtDW -> UnitDelay2_DSTATE = _rtB -> B_22_63_0 ;
} isHit = ssIsSampleHit ( S , 2 , 0 ) ; if ( isHit != 0 ) { _rtDW ->
Integrator_DSTATE = _rtB -> B_22_100_0 ; _rtDW -> Integrator_PrevResetState =
( int8_T ) _rtB -> B_22_99_0 ; } isHit = ssIsSampleHit ( S , 4 , 0 ) ; if (
isHit != 0 ) { _rtDW -> UnitDelay15_DSTATE = _rtB -> B_22_64_0 ; } isHit =
ssIsSampleHit ( S , 2 , 0 ) ; if ( isHit != 0 ) { _rtDW ->
Integrator_DSTATE_c = _rtB -> B_22_113_0 ; _rtDW ->
Integrator_PrevResetState_k = ( int8_T ) _rtB -> B_22_108_0 ; } isHit =
ssIsSampleHit ( S , 4 , 0 ) ; if ( isHit != 0 ) { _rtDW -> UnitDelay1_DSTATE
= _rtB -> B_22_65_0 ; } isHit = ssIsSampleHit ( S , 2 , 0 ) ; if ( isHit != 0
) { _rtDW -> Integrator_DSTATE_a = _rtB -> B_22_119_0 ; _rtDW ->
Integrator_PrevResetState_a = ( int8_T ) _rtB -> B_22_109_0 ; } { real_T * *
uBuffer = ( real_T * * ) & _rtDW -> TransportDelay2_PWORK . TUbufferPtrs [ 0
] ; real_T * * tBuffer = ( real_T * * ) & _rtDW -> TransportDelay2_PWORK .
TUbufferPtrs [ 1 ] ; real_T simTime = ssGetT ( S ) ; _rtDW ->
TransportDelay2_IWORK . Head = ( ( _rtDW -> TransportDelay2_IWORK . Head < (
_rtDW -> TransportDelay2_IWORK . CircularBufSize - 1 ) ) ? ( _rtDW ->
TransportDelay2_IWORK . Head + 1 ) : 0 ) ; if ( _rtDW ->
TransportDelay2_IWORK . Head == _rtDW -> TransportDelay2_IWORK . Tail ) { if
( ! TramWay_Charging_108V_full_test_acc_rt_TDelayUpdateTailOrGrowBuf ( &
_rtDW -> TransportDelay2_IWORK . CircularBufSize , & _rtDW ->
TransportDelay2_IWORK . Tail , & _rtDW -> TransportDelay2_IWORK . Head , &
_rtDW -> TransportDelay2_IWORK . Last , simTime - _rtP -> P_94 , tBuffer ,
uBuffer , ( NULL ) , ( boolean_T ) 0 , false , & _rtDW ->
TransportDelay2_IWORK . MaxNewBufSize ) ) { ssSetErrorStatus ( S ,
"tdelay memory allocation error" ) ; return ; } } ( * tBuffer ) [ _rtDW ->
TransportDelay2_IWORK . Head ] = simTime ; ( * uBuffer ) [ _rtDW ->
TransportDelay2_IWORK . Head ] = _rtB -> B_22_91_0 ; } { real_T * * uBuffer =
( real_T * * ) & _rtDW -> TransportDelay3_PWORK . TUbufferPtrs [ 0 ] ; real_T
* * tBuffer = ( real_T * * ) & _rtDW -> TransportDelay3_PWORK . TUbufferPtrs
[ 1 ] ; real_T simTime = ssGetT ( S ) ; _rtDW -> TransportDelay3_IWORK . Head
= ( ( _rtDW -> TransportDelay3_IWORK . Head < ( _rtDW ->
TransportDelay3_IWORK . CircularBufSize - 1 ) ) ? ( _rtDW ->
TransportDelay3_IWORK . Head + 1 ) : 0 ) ; if ( _rtDW ->
TransportDelay3_IWORK . Head == _rtDW -> TransportDelay3_IWORK . Tail ) { if
( ! TramWay_Charging_108V_full_test_acc_rt_TDelayUpdateTailOrGrowBuf ( &
_rtDW -> TransportDelay3_IWORK . CircularBufSize , & _rtDW ->
TransportDelay3_IWORK . Tail , & _rtDW -> TransportDelay3_IWORK . Head , &
_rtDW -> TransportDelay3_IWORK . Last , simTime - _rtP -> P_98 , tBuffer ,
uBuffer , ( NULL ) , ( boolean_T ) 0 , false , & _rtDW ->
TransportDelay3_IWORK . MaxNewBufSize ) ) { ssSetErrorStatus ( S ,
"tdelay memory allocation error" ) ; return ; } } ( * tBuffer ) [ _rtDW ->
TransportDelay3_IWORK . Head ] = simTime ; ( * uBuffer ) [ _rtDW ->
TransportDelay3_IWORK . Head ] = _rtB -> B_22_91_0 ; } isHit = ssIsSampleHit
( S , 2 , 0 ) ; if ( isHit != 0 ) { _rtDW -> UnitDelay11_DSTATE = _rtB ->
B_22_141_0 ; _rtDW -> UnitDelay14_DSTATE = _rtB -> B_22_137_0 ; _rtDW ->
UnitDelay16_DSTATE = _rtB -> B_22_142_0 ; } isHit = ssIsSampleHit ( S , 4 , 0
) ; if ( isHit != 0 ) { _rtDW -> UnitDelay15_DSTATE_l = 0.0 ; } { real_T * *
uBuffer = ( real_T * * ) & _rtDW -> TransportDelay2_PWORK_d . TUbufferPtrs [
0 ] ; real_T * * tBuffer = ( real_T * * ) & _rtDW -> TransportDelay2_PWORK_d
. TUbufferPtrs [ 1 ] ; real_T simTime = ssGetT ( S ) ; _rtDW ->
TransportDelay2_IWORK_h . Head = ( ( _rtDW -> TransportDelay2_IWORK_h . Head
< ( _rtDW -> TransportDelay2_IWORK_h . CircularBufSize - 1 ) ) ? ( _rtDW ->
TransportDelay2_IWORK_h . Head + 1 ) : 0 ) ; if ( _rtDW ->
TransportDelay2_IWORK_h . Head == _rtDW -> TransportDelay2_IWORK_h . Tail ) {
if ( ! TramWay_Charging_108V_full_test_acc_rt_TDelayUpdateTailOrGrowBuf ( &
_rtDW -> TransportDelay2_IWORK_h . CircularBufSize , & _rtDW ->
TransportDelay2_IWORK_h . Tail , & _rtDW -> TransportDelay2_IWORK_h . Head ,
& _rtDW -> TransportDelay2_IWORK_h . Last , simTime - _rtP -> P_120 , tBuffer
, uBuffer , ( NULL ) , ( boolean_T ) 0 , false , & _rtDW ->
TransportDelay2_IWORK_h . MaxNewBufSize ) ) { ssSetErrorStatus ( S ,
"tdelay memory allocation error" ) ; return ; } } ( * tBuffer ) [ _rtDW ->
TransportDelay2_IWORK_h . Head ] = simTime ; ( * uBuffer ) [ _rtDW ->
TransportDelay2_IWORK_h . Head ] = _rtB -> B_22_148_0 ; } { real_T * *
uBuffer = ( real_T * * ) & _rtDW -> TransportDelay3_PWORK_e . TUbufferPtrs [
0 ] ; real_T * * tBuffer = ( real_T * * ) & _rtDW -> TransportDelay3_PWORK_e
. TUbufferPtrs [ 1 ] ; real_T simTime = ssGetT ( S ) ; _rtDW ->
TransportDelay3_IWORK_a . Head = ( ( _rtDW -> TransportDelay3_IWORK_a . Head
< ( _rtDW -> TransportDelay3_IWORK_a . CircularBufSize - 1 ) ) ? ( _rtDW ->
TransportDelay3_IWORK_a . Head + 1 ) : 0 ) ; if ( _rtDW ->
TransportDelay3_IWORK_a . Head == _rtDW -> TransportDelay3_IWORK_a . Tail ) {
if ( ! TramWay_Charging_108V_full_test_acc_rt_TDelayUpdateTailOrGrowBuf ( &
_rtDW -> TransportDelay3_IWORK_a . CircularBufSize , & _rtDW ->
TransportDelay3_IWORK_a . Tail , & _rtDW -> TransportDelay3_IWORK_a . Head ,
& _rtDW -> TransportDelay3_IWORK_a . Last , simTime - _rtP -> P_122 , tBuffer
, uBuffer , ( NULL ) , ( boolean_T ) 0 , false , & _rtDW ->
TransportDelay3_IWORK_a . MaxNewBufSize ) ) { ssSetErrorStatus ( S ,
"tdelay memory allocation error" ) ; return ; } } ( * tBuffer ) [ _rtDW ->
TransportDelay3_IWORK_a . Head ] = simTime ; ( * uBuffer ) [ _rtDW ->
TransportDelay3_IWORK_a . Head ] = _rtB -> B_22_148_0 ; } isHit =
ssIsSampleHit ( S , 1 , 0 ) ; if ( isHit != 0 ) { _rtDW ->
Memory2_PreviousInput_h = _rtB -> B_22_294_0 ; _rtDW ->
Memory_PreviousInput_k = _rtB -> B_22_368_0 ; _rtDW -> Delay_DSTATE [ _rtDW
-> CircBufIdx ] = _rtB -> B_22_367_0 ; if ( _rtDW -> CircBufIdx < 799U ) {
_rtDW -> CircBufIdx ++ ; } else { _rtDW -> CircBufIdx = 0U ; } _rtDW ->
Memory1_PreviousInput = _rtB -> B_22_286_0 ; } isHit = ssIsSampleHit ( S , 2
, 0 ) ; if ( isHit != 0 ) { _rtDW -> UnitDelay11_DSTATE_h = _rtB ->
B_22_410_0 ; _rtDW -> UnitDelay14_DSTATE_d = _rtB -> B_22_406_0 ; } isHit =
ssIsSampleHit ( S , 4 , 0 ) ; if ( isHit != 0 ) { _rtDW ->
UnitDelay15_DSTATE_e = 0.0 ; } UNUSED_PARAMETER ( tid ) ; }
#define MDL_UPDATE
static void mdlUpdateTID6 ( SimStruct * S , int_T tid ) { UNUSED_PARAMETER (
tid ) ; }
#define MDL_DERIVATIVES
static void mdlDerivatives ( SimStruct * S ) {
B_TramWay_Charging_108V_full_test_T * _rtB ;
XDot_TramWay_Charging_108V_full_test_T * _rtXdot ; _rtXdot = ( (
XDot_TramWay_Charging_108V_full_test_T * ) ssGetdX ( S ) ) ; _rtB = ( (
B_TramWay_Charging_108V_full_test_T * ) _ssGetModelBlockIO ( S ) ) ; if ( !
_rtB -> B_22_152_0 ) { _rtXdot -> Integrator_CSTATE = _rtB -> B_22_165_0 ; }
else { _rtXdot -> Integrator_CSTATE = 0.0 ; } if ( ! _rtB -> B_22_299_0 ) {
_rtXdot -> Integrator_CSTATE_k = _rtB -> B_22_355_0 ; } else { _rtXdot ->
Integrator_CSTATE_k = 0.0 ; } _rtXdot -> Integrator_CSTATE_l = _rtB ->
B_22_354_0 ; } static void mdlInitializeSizes ( SimStruct * S ) {
ssSetChecksumVal ( S , 0 , 1233635785U ) ; ssSetChecksumVal ( S , 1 ,
178230554U ) ; ssSetChecksumVal ( S , 2 , 1292957704U ) ; ssSetChecksumVal (
S , 3 , 21962059U ) ; { mxArray * slVerStructMat = NULL ; mxArray * slStrMat
= mxCreateString ( "simulink" ) ; char slVerChar [ 10 ] ; int status =
mexCallMATLAB ( 1 , & slVerStructMat , 1 , & slStrMat , "ver" ) ; if ( status
== 0 ) { mxArray * slVerMat = mxGetField ( slVerStructMat , 0 , "Version" ) ;
if ( slVerMat == NULL ) { status = 1 ; } else { status = mxGetString (
slVerMat , slVerChar , 10 ) ; } } mxDestroyArray ( slStrMat ) ;
mxDestroyArray ( slVerStructMat ) ; if ( ( status == 1 ) || ( strcmp (
slVerChar , "9.1" ) != 0 ) ) { return ; } } ssSetOptions ( S ,
SS_OPTION_EXCEPTION_FREE_CODE ) ; if ( ssGetSizeofDWork ( S ) != sizeof (
DW_TramWay_Charging_108V_full_test_T ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal DWork sizes do "
"not match for accelerator mex file." ) ; } if ( ssGetSizeofGlobalBlockIO ( S
) != sizeof ( B_TramWay_Charging_108V_full_test_T ) ) { ssSetErrorStatus ( S
, "Unexpected error: Internal BlockIO sizes do "
"not match for accelerator mex file." ) ; } { int ssSizeofParams ;
ssGetSizeofParams ( S , & ssSizeofParams ) ; if ( ssSizeofParams != sizeof (
P_TramWay_Charging_108V_full_test_T ) ) { static char msg [ 256 ] ; sprintf (
msg , "Unexpected error: Internal Parameters sizes do "
"not match for accelerator mex file." ) ; } } _ssSetModelRtp ( S , ( real_T *
) & TramWay_Charging_108V_full_test_rtDefaultP ) ; _ssSetConstBlockIO ( S , &
TramWay_Charging_108V_full_test_rtInvariant ) ; rt_InitInfAndNaN ( sizeof (
real_T ) ) ; ( ( P_TramWay_Charging_108V_full_test_T * ) ssGetModelRtp ( S )
) -> P_2 = rtMinusInf ; ( ( P_TramWay_Charging_108V_full_test_T * )
ssGetModelRtp ( S ) ) -> P_16 = rtMinusInf ; } static void
mdlInitializeSampleTimes ( SimStruct * S ) { slAccRegPrmChangeFcn ( S ,
mdlOutputsTID6 ) ; } static void mdlTerminate ( SimStruct * S ) { }
#include "simulink.c"
